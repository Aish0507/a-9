import { Navigate, Route, Routes } from "react-router-dom";
import { DebtorDashboard } from "../components/DebtorDashboard";
import { DebtorRequestForm } from "../components/DebtorRequestForm";

export const DebtorRoutes = ()  => {
    return (
    <Routes>
     <Route path="/" element={<Navigate to="dashboard" />} />
      <Route path="dashboard" element={<DebtorDashboard />} />
      <Route path="create-offer" element={<DebtorRequestForm />} />
    </Routes>
  );
};