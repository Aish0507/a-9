// export const DebtorDashboard = () => <div>Debtor Dashboard</div>;
// import React from 'react';
import {
  UserIcon,
  BanknotesIcon,
  ClockIcon,
  CurrencyRupeeIcon,
} from '@heroicons/react/24/outline';

const stats = [
  {
    label: 'Total Debtors',
    value: 245,
    icon: UserIcon,
  },
  {
    label: 'Outstanding Loans',
    value: '₹3.8L',
    icon: BanknotesIcon,
  },
  {
    label: 'Overdue Payments',
    value: 17,
    icon: ClockIcon,
  },
  {
    label: 'Monthly Repayment',
    value: '₹92K',
    icon: CurrencyRupeeIcon,
  },
];

export const DebtorDashboard = () => {
  return (
    <div className="p-6">
      {/* Header */}
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
        <UserIcon className="w-6 h-6 text-blue-600" />
        Debtor Dashboard
      </h2>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="bg-white border shadow-sm p-4 rounded-lg flex items-center gap-4"
          >
            <stat.icon className="w-10 h-10 text-blue-500" />
            <div>
              <p className="text-gray-500 text-sm">{stat.label}</p>
              <p className="text-xl font-semibold text-gray-800">
                {stat.value}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Repayment Activity */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-800">
          Recent Repayment Activity
        </h3>
        <p className="text-sm text-gray-600">
          This section will show repayments made by debtors, upcoming EMIs, or overdue notices.
        </p>
      </div>
    </div>
  );
};

// export default DebtorDashboard;
