// export const CreditorDashboard = () => <div>Creditor Dashboard</div>;
// import React from 'react';
import {
  BanknotesIcon,
  UserGroupIcon,
  ClockIcon,
  ArrowTrendingUpIcon,
} from '@heroicons/react/24/outline';
import ChatBot from './ChatBot';
import KisanChatBot from './KisanChatBot';
import LanguageSwitcher from '../../../components/LanguageSwitcher';

const stats = [
  {
    label: 'Total Creditors',
    value: 128,
    icon: UserGroupIcon,
  },
  {
    label: 'Active Loans',
    value: 94,
    icon: BanknotesIcon,
  },
  {
    label: 'Pending Approvals',
    value: 12,
    icon: ClockIcon,
  },
  {
    label: 'Monthly Payouts',
    value: '₹2.3L',
    icon: ArrowTrendingUpIcon,
  },
];

export const CreditorDashboard = () => {
  return (
    <>
    <KisanChatBot />

    </>
  
  );
};

// export default CreditorDashboard;
