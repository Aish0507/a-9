// ChatBot.tsx
import React, { useState } from 'react';


const cropReleases = [
    {
        id: 1,
        name: 'धान (Rice)',
        description: 'न्यूनतम समर्थन मूल्य (MSP): ₹2,183 / क्विंटल | मंडी रेट: ₹2,000 - ₹2,250',
        image: 'https://cdn.pixabay.com/photo/2017/01/20/00/30/rice-1993255_1280.jpg',
    },
    {
        id: 2,
        name: 'गेहूं (Wheat)',
        description: 'MSP: ₹2,125 / क्विंटल | मंडी रेट: ₹2,100 - ₹2,250',
        image: 'https://cdn.pixabay.com/photo/2016/11/21/16/12/wheat-1845835_1280.jpg',
    },
    {
        id: 3,
        name: 'चना (Gram)',
        description: 'MSP: ₹5,440 / क्विंटल | मंडी रेट: ₹5,300 - ₹5,600',
        image: 'https://cdn.pixabay.com/photo/2018/03/27/15/17/chickpeas-3266472_1280.jpg',
    },
];


export default function ChatBot() {
    const [messages, setMessages] = useState([
        { from: 'bot', text: 'Sure, which item would you like?' },
    ]);

    const [step, setStep] = useState(1);
    const [inputMessage, setInputMessage] = useState('');
    const handleSend = () => {
        if (!inputMessage.trim()) return;

        // Add user message
        setMessages((prev) => [...prev, { from: 'user', text: inputMessage }]);

        // Optionally add bot response
        setTimeout(() => {
            setMessages((prev) => [...prev, { from: 'bot', text: "Got it! 🍕 Anything else?" }]);
        }, 600);

        // Clear input field
        setInputMessage('');
    };


    const handleAddToOrder = () => {
        setMessages((prev) => [...prev, { from: 'user', text: 'Add to Order' }]);
        setMessages((prev) => [...prev, { from: 'bot', text: 'आप किस फ़सल के लिए जानकारी चाहते हैं?' }]);
        setStep(2);
    };

    const handleSizeSelect = (size) => {
        setMessages((prev) => [...prev, { from: 'user', text: size }]);
    };

    return (
        <div className="max-w-md mx-auto bg-gray-100 rounded-xl shadow-md p-4 space-y-4 h-[90vh] flex flex-col">
            {/* Header */}
            <div className="text-center font-semibold text-lg text-green-700">
                किसान सहाय ऐप | Kisan Sahay Chat
            </div>

            {/* Scrollable Chat */}
            <div className="flex-1 overflow-y-auto space-y-4">
                {messages.map((msg, i) => (
                    <div
                        key={i}
                        className={`flex ${msg.from === 'bot' ? 'justify-start' : 'justify-end'}`}
                    >
                        <div
                            className={`px-4 py-2 rounded-lg max-w-xs ${msg.from === 'bot'
                                ? 'bg-white text-gray-800'
                                : 'bg-blue-500 text-white'
                                }`}
                        >
                            {msg.text}
                        </div>
                    </div>
                ))}


                {/* Pizza Options with Fixed Card Height */}
                {step === 1 && (
                    <div className="overflow-x-auto py-2">
                        <div className="flex gap-4" style={{ minWidth: '100%' }}>
                            {cropReleases.map((pizza) => (
                                <div
                                    key={pizza.id}
                                    className="w-[200px] h-[300px] flex-shrink-0 bg-white rounded-xl shadow-md overflow-hidden flex flex-col"
                                >
                                    {/* Image */}
                                    <img
                                        src={pizza.image}
                                        alt={pizza.name}
                                        className="w-full h-32 object-cover"
                                    />

                                    {/* Content Area */}
                                    <div className="p-2 flex flex-col justify-between flex-1">
                                        <div>
                                            <div className="font-bold text-sm mb-1">{pizza.name}</div>
                                            <p className="text-xs text-gray-600 line-clamp-3">
                                                {pizza.description}
                                            </p>
                                        </div>

                                        <button
                                            onClick={handleAddToOrder}
                                            className="mt-2 bg-blue-600 text-white text-xs px-3 py-1 rounded self-start"
                                        >
                                            जानकारी देखें
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}




                {/* Size Options */}
                {step === 2 && (
                    <div className="flex flex-wrap gap-2">
                        {['Small (10")', 'Medium (12")', 'Large (14")'].map((size) => (
                            <button
                                key={size}
                                onClick={() => handleSizeSelect(size)}
                                className="bg-gray-200 hover:bg-gray-300 text-sm px-4 py-2 rounded-full"
                            >
                                {size}
                            </button>
                        ))}
                    </div>
                )}
            </div>

            {/* Footer Input */}
            {/* Footer Input */}
            <div className="bg-white- p-3 rounded-xl shadow-md flex items-center gap-2">
                <button className="text-gray-500 text-xl">📎</button>
                <button className="text-gray-500 text-xl">📷</button>
                <button className="text-gray-500 text-xl">🎤</button>
                <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Type a message"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-full text-sm outline-none"
                />
                <button
                    onClick={handleSend}
                    className="text-blue-500 font-semibold text-sm px-2"
                >
                    Send
                </button>
            </div>

        </div>
    );

}
