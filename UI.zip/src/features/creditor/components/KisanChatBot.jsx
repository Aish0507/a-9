import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import LanguageSwitcher from "../../../components/LanguageSwitcher";
import FooterInputBar from "../../../components/FooterInputBar";

const cropReleases = [
    {
        id: 1,
        nameKey: "crops.rice.name",
        descriptionKey: "crops.rice.description",
        image:
            "https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg",
    },
    {
        id: 2,
        nameKey: "crops.wheat.name",
        descriptionKey: "crops.wheat.description",
        image:
            "https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg",
    },
    {
        id: 3,
        nameKey: "crops.gram.name",
        descriptionKey: "crops.gram.description",
        image:
            "https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg",
    },
];

export default function KisanChatBot() {
    const { t } = useTranslation();
    const [messages, setMessages] = useState([
        { from: "bot", text: t("chatbot.greeting") },
    ]);
    const [step, setStep] = useState(1);
    const [inputMessage, setInputMessage] = useState("");
    const [isListening, setIsListening] = useState(false);

    const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;

    const handleMicClick = () => {
        if (!SpeechRecognition) {
            alert(t("chatbot.speechNotSupported"));
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.lang = "hi-IN";
        recognition.continuous = false;
        recognition.interimResults = false;

        setIsListening(true);

        recognition.onresult = (event) => {
            const speechToText = event.results[0][0].transcript;
            setInputMessage(speechToText);
            setIsListening(false);
        };

        recognition.onerror = () => {
            alert(t("chatbot.speechError"));
            setIsListening(false);
        };

        recognition.start();
    };

    const handleAddToOrder = (cropName) => {
        setMessages((prev) => [
            ...prev,
            { from: "user", text: cropName + t("chatbot.viewInfoSuffix") },
        ]);
        setMessages((prev) => [
            ...prev,
            { from: "bot", text: t("chatbot.anythingElse") },
        ]);
        setStep(2);
    };

    const handleSend = () => {
        if (!inputMessage.trim()) return;
        setMessages((prev) => [...prev, { from: "user", text: inputMessage }]);
        setTimeout(() => {
            setMessages((prev) => [
                ...prev,
                { from: "bot", text: t("chatbot.thankYou") },
            ]);
        }, 500);
        setInputMessage("");
    };

    return (
        // <div
        //     className="min-h-screen flex items-center justify-center px-4 py-6 bg-gradient-to-br from-green-50 via-white to-green-100">

        //     {/* 🌐 Language Switcher */}
        //     <LanguageSwitcher />

        //     {/* 📦 Main Chat Container */}
        //     <div
        //         className="relative w-full max-w-md h-[95vh] bg-white/60 backdrop-blur-xl border border-green-200 shadow-xl rounded-3xl flex flex-col p-4 space-y-4 overflow-hidden">

        //         {/* 🧾 Header */}
        //         <h1 className="text-center text-2xl font-bold text-green-800 tracking-tight">
        //             {t('chatbot.title')}
        //         </h1>

        //         {/* 💬 Messages */}
        //         <div
        //             className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-green-300 scrollbar-track-green-100 space-y-3 pr-1">
        //             {messages.map((msg, i) => (
        //                 <div key={i} className={`flex ${msg.from === 'bot' ? 'justify-start' : 'justify-end'}`}>
        //                     <div className={`px-4 py-2 rounded-2xl shadow text-sm max-w-[80%] ${msg.from === 'bot'
        //                         ? 'bg-white text-gray-800 border border-green-100' : 'bg-green-600 text-white'}`}>
        //                         {msg.text}
        //                     </div>
        //                 </div>
        //             ))}

        //             {/* 🌾 Crop Recommendations */}
        //             {step === 1 && (
        //                 <div className="py-3">
        //                     <h2 className="text-sm font-semibold text-gray-600 px-1">📈 शिफारस केलेले पीक</h2>
        //                     <div className="flex gap-3 overflow-x-auto scrollbar-thin pt-2">
        //                         {cropReleases.map((crop) => (
        //                             <div key={crop.id}
        //                                 className="w-[160px] sm:w-[180px] bg-white border border-green-100 rounded-2xl shadow-md flex flex-col hover:shadow-lg transition-all">
        //                                 <img src={crop.image} alt={t(crop.nameKey)}
        //                                     className="rounded-t-2xl h-24 object-cover w-full" />
        //                                 <div className="p-2 flex flex-col justify-between h-full">
        //                                     <div>
        //                                         <h3 className="text-green-700 font-semibold text-sm">{t(crop.nameKey)}</h3>
        //                                         <p className="text-xs text-gray-600 line-clamp-3">{t(crop.descriptionKey)}</p>
        //                                     </div>
        //                                     <button onClick={() => handleAddToOrder(t(crop.nameKey))}
        //                                         className="mt-2 text-xs bg-green-600 hover:bg-green-700 text-white px-2 py-1
        //                         rounded-full transition-all">
        //                                         {t('chatbot.viewInfo')}
        //                                     </button>
        //                                 </div>
        //                             </div>
        //                         ))}
        //                     </div>
        //                 </div>
        //             )}
        //         </div>

        //         {/* 📝 Input */}
        //         <div
        //             className="flex items-center gap-2 bg-white backdrop-blur-md rounded-full px-4 py-2 shadow border border-gray-200">
        //             {/* Icons */}
        //             <div className="flex items-center gap-2 text-gray-500 text-xl">
        //                 <button className="hover:text-green-600">📎</button>
        //                 <button className="hover:text-green-600">📷</button>
        //                 <button onClick={handleMicClick} className={`${isListening ? 'text-red-500 animate-pulse'
        //                     : 'hover:text-green-600'}`}>
        //                     🎤
        //                 </button>
        //             </div>

        //             {/* Input Field */}
        //             <input type="text" value={inputMessage} onChange={(e) => setInputMessage(e.target.value)}
        //                 onKeyDown={(e) => e.key === 'Enter' && handleSend()}
        //                 placeholder={t('chatbot.typePlaceholder')}
        //                 className="flex-1 bg-transparent focus:outline-none text-sm placeholder-gray-400 px-2" />

        //             {/* Send */}
        //             <button onClick={handleSend} className="text-green-700 font-bold hover:text-green-900 text-sm">
        //                 {t('chatbot.send')}
        //             </button>
        //         </div>
        //     </div>
        // </div>
        <div className="min-h-screen bg-gradient-to-b from-[#0b0f1c] to-[#152034] text-white flex flex-col justify-between p-4 sm:px-6 font-sans">
            {/* Header */}
            <div className="flex items-center gap-3 pb-4">
                {/* <img
                    src="/assets/avatar.png"
                    alt="Bot Avatar"
                    className="w-10 h-10 rounded-lg border border-gray-600 shadow"
                /> */}
                {'<'}
                <div>
                    <h1 className="font-semibold text-sm">This is my favorite...</h1>
                    <p className="text-xs text-gray-400">Last Update: 12.02.26</p>
                </div>
                <div className="ml-auto flex items-center gap-3 text-gray-400">
                    <button>🔊</button>
                    <button>↻</button>
                </div>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto space-y-5">
                {/* User Message */}
                <div className="flex justify-end">
                    <div className="bg-blue-500 text-sm px-4 py-2 rounded-xl max-w-[75%] shadow-md">
                        Which movie are you most excited to see?
                    </div>
                </div>

                {/* Bot Response */}
                <div className="flex justify-start">
                    <div className="bg-[#1a1f2e] text-sm px-4 py-3 rounded-xl max-w-[85%] text-gray-100 shadow-sm leading-relaxed">
                        That’s a tough question, as I find all of these movies interesting
                        in their own way. But if I had to choose one, I would say{" "}
                        <span className="font-semibold text-white">
                            Avatar: The Way of Water
                        </span>
                        , because I’m curious to see how James Cameron will expand the world
                        of Pandora and create.
                    </div>
                </div>

                {/* Timestamp */}
                <div className="text-xs text-center text-gray-500 border-t border-dashed border-gray-600 pt-2">
                    10:30am - 12.02.26
                </div>

                {/* Another User Message */}
                <div className="flex justify-end">
                    <div className="bg-blue-500 text-sm px-4 py-2 rounded-xl max-w-[75%] shadow-md">
                        Cat and dog and sea and Dota 2
                    </div>
                </div>

                {/* Image Grid from Bot */}
                <div className="flex justify-start">
                    <div className="grid grid-cols-2 gap-2 p-2 rounded-xl bg-[#1a1f2e] shadow-inner">
                        <img
                            src="https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg"
                            className="rounded-lg object-cover w-28 h-28"
                        />
                        <img
                            src="https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg"
                            className="rounded-lg object-cover w-28 h-28"
                        />
                        <img
                            src="https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg"
                            className="rounded-lg object-cover w-28 h-28"
                        />
                        <img
                            src="https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg"
                            className="rounded-lg object-cover w-28 h-28"
                        />
                    </div>
                </div>
            </div>

            {/* Input Field */}
            {/* <div className="mt-4 px-3 py-2 rounded-full bg-[#1a1f2f] border border-[#2b3145] flex items-center gap-3">
        <button className="text-gray-400 hover:text-white text-lg">📎</button>
        <button className="text-gray-400 hover:text-white text-lg">🎤</button>
        <input
          type="text"
          placeholder="Ask me anything..."
          className="flex-1 bg-transparent outline-none text-sm placeholder-gray-400 text-white"
        />
        <button className="text-white hover:text-blue-400 text-lg">➤</button>
      </div> */}
            <FooterInputBar />

        </div>
    );
}
