import { Navigate, Route, Routes } from "react-router-dom";
import { CreditorDashboard } from "../components/CreditorDashboard";
import { CreditorOfferForm } from "../components/CreditorOfferForm";
import ChatIntroScreen from "../../../components/ChatIntroScreen";
import ChatPromptScreen from "../../../components/ChatPromptScreen";

export const CreditorRoutes = () => {
    return (
    <Routes>
     <Route path="/" element={<Navigate to="dashboard" />} />
      <Route path="dashboard" element={<CreditorDashboard />} />
      <Route path="create-offer" element={<CreditorOfferForm />} />
      <Route path="intro" element={<ChatIntroScreen />} />
      <Route path="prompt" element={<ChatPromptScreen />} />
    </Routes>
  );
};