// export const ReminderManager = () => <div>Reminder Manager</div>;
// import React from 'react';
import {
  BellIcon,
  PencilSquareIcon,
  TrashIcon,
  PlusIcon,
} from '@heroicons/react/24/outline';

const reminders = [
  {
    id: 1,
    title: 'Submit quarterly report',
    description: 'Due on July 25, 2025',
    date: '2025-07-25',
  },
  {
    id: 2,
    title: 'Schedule volunteer meet',
    description: 'Send invites for August 5th session',
    date: '2025-07-20',
  },
  {
    id: 3,
    title: 'Renew FCRA license',
    description: 'Before end of this month',
    date: '2025-07-28',
  },
];

export const ReminderManager = () => {
  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <BellIcon className="w-6 h-6 text-blue-600" />
          Reminders
        </h2>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
          <PlusIcon className="w-5 h-5" />
          Add Reminder
        </button>
      </div>

      {/* Reminder List */}
      <div className="space-y-4">
        {reminders.map((reminder) => (
          <div
            key={reminder.id}
            className="bg-white rounded-lg shadow-sm p-4 flex justify-between items-start border hover:shadow-md transition"
          >
            <div>
              <h3 className="text-lg font-semibold text-gray-800">{reminder.title}</h3>
              <p className="text-sm text-gray-600">{reminder.description}</p>
              <p className="text-xs text-gray-400 mt-1">Due: {reminder.date}</p>
            </div>
            <div className="flex space-x-3">
              <button className="text-blue-500 hover:text-blue-700">
                <PencilSquareIcon className="w-5 h-5" />
              </button>
              <button className="text-red-500 hover:text-red-700">
                <TrashIcon className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// export default Reminder;
