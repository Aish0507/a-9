// export const NGODashboard = () => <div>NGO Dashboard</div>;
import { Link } from 'react-router-dom';
import {
  Bars3Icon,
  XMarkIcon,
  HomeIcon,
  UsersIcon,
  BanknotesIcon,
} from '@heroicons/react/24/outline';
import { useState } from 'react';
export const NGODashboard = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
  return (
    <div className="flex h-screen ">
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 p-6 overflow-y-auto">
          <h2 className="text-2xl font-bold mb-6">Welcome to NGO Dashboard</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <DashboardCard title="Incoming Debtor Requests" value="128" />
            <DashboardCard title="Pending Creditor Approvals" value="64" />
            <DashboardCard title="Active Contracts" value="27" />
            <DashboardCard title="Pending Verifications" value="8" />
            <DashboardCard title="Grievance Forms" value="12" />
            <DashboardCard title="Blacklisted Accounts" value="5" />
          </div>
        </main>
      </div>
    </div>
  );
};

// eslint-disable-next-line react/prop-types
const DashboardCard = ({ title, value }) => (
  <div className="bg-white p-6 rounded-xl shadow hover:shadow-lg transition-all">
    <h2 className="text-sm font-medium text-gray-500">{title}</h2>
    <p className="text-2xl font-bold text-blue-600 mt-2">{value}</p>
  </div>
);

// export default Dashboard;
