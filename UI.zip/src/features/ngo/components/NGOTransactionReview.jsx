import {
  ArrowDownTrayIcon,
  MagnifyingGlassIcon,
} from '@heroicons/react/24/outline';

const transactions = [
  {
    id: 'TXN001',
    creditor: 'ABC Foundation',
    debtor: 'XYZ NGO',
    amount: '₹10,000',
    date: '2025-07-01',
    status: 'Completed',
  },
  {
    id: 'TXN002',
    creditor: 'Green Earth Trust',
    debtor: 'FutureAid',
    amount: '₹5,500',
    date: '2025-07-15',
    status: 'Pending',
  },
  {
    id: 'TXN003',
    creditor: 'Hope Bank',
    debtor: 'ServeWell',
    amount: '₹8,000',
    date: '2025-07-17',
    status: 'Failed',
  },
];

const statusColors = {
  Completed: 'bg-green-100 text-green-800',
  Pending: 'bg-yellow-100 text-yellow-800',
  Failed: 'bg-red-100 text-red-800',
};

export const NGOTransactionReview = () => {
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Transactions</h2>
        <button className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
          <ArrowDownTrayIcon className="w-5 h-5" />
          <span>Export</span>
        </button>
      </div>

      {/* Search bar */}
      <div className="mb-4 relative max-w-md">
        <input
          type="text"
          placeholder="Search transactions..."
          className="w-full pl-10 pr-4 py-2 border rounded shadow-sm focus:outline-none focus:ring focus:border-blue-300"
        />
        <MagnifyingGlassIcon className="w-5 h-5 text-gray-500 absolute left-3 top-2.5" />
      </div>

      {/* Transactions Table */}
      <div className="overflow-x-auto  rounded shadow">
        <table className="min-w-full table-auto">
          <thead className="text-left">
            <tr>
              <th className="p-4 font-medium">Transaction ID</th>
              <th className="p-4 font-medium">Creditor</th>
              <th className="p-4 font-medium">Debtor</th>
              <th className="p-4 font-medium">Amount</th>
              <th className="p-4 font-medium">Date</th>
              <th className="p-4 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((txn) => (
              <tr key={txn.id} className="border-t hover:bg-slate-600">
                <td className="p-4">{txn.id}</td>
                <td className="p-4">{txn.creditor}</td>
                <td className="p-4">{txn.debtor}</td>
                <td className="p-4">{txn.amount}</td>
                <td className="p-4">{txn.date}</td>
                <td className="p-4">
                  <span
                    className={`text-sm px-3 py-1 rounded-full font-medium ${statusColors[txn.status]}`}
                  >
                    {txn.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// export default Transactions;
