// export const VolunteerAssistancePanel = () => <div>Volunteer Assistance Panel</div>;
// import React from 'react';
import {
  UserIcon,
  PhoneIcon,
  EnvelopeIcon,
  MapPinIcon,
  PlusIcon,
} from '@heroicons/react/24/outline';

const volunteers = [
  {
    id: 1,
    name: 'Aditi Sharma',
    email: 'aditi@example.com',
    phone: '+91 98765 43210',
    location: 'Mumbai, India',
  },
  {
    id: 2,
    name: 'Rahul Verma',
    email: 'rahulv@example.com',
    phone: '+91 91234 56789',
    location: 'Delhi, India',
  },
  {
    id: 3,
    name: 'Sneha Iyer',
    email: 'sneha.iyer@example.com',
    phone: '+91 99887 11223',
    location: 'Bangalore, India',
  },
];

export const VolunteerAssistancePanel = () => {
  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <UserIcon className="w-6 h-6 text-purple-600" />
          Volunteers
        </h2>
        <button className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
          <PlusIcon className="w-5 h-5" />
          Add Volunteer
        </button>
      </div>

      {/* Volunteer Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {volunteers.map((volunteer) => (
          <div
            key={volunteer.id}
            className="bg-white shadow rounded-lg p-4 border hover:shadow-md transition"
          >
            <h3 className="text-lg font-semibold text-gray-800 mb-1">
              {volunteer.name}
            </h3>
            <div className="text-sm text-gray-600 flex items-center gap-2">
              <EnvelopeIcon className="w-4 h-4 text-gray-400" />
              {volunteer.email}
            </div>
            <div className="text-sm text-gray-600 flex items-center gap-2 mt-1">
              <PhoneIcon className="w-4 h-4 text-gray-400" />
              {volunteer.phone}
            </div>
            <div className="text-sm text-gray-600 flex items-center gap-2 mt-1">
              <MapPinIcon className="w-4 h-4 text-gray-400" />
              {volunteer.location}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// export default Volunteer;
