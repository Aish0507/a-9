import React, { useState } from 'react';
import { Link, Outlet } from 'react-router-dom';
import {
  Bars3Icon,
  XMarkIcon,
  HomeIcon,
  UsersIcon,
  BanknotesIcon,
} from '@heroicons/react/24/outline';

const NGOLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  return (
    <div className="flex h-screen ">
      {/* Sidebar */}
      <div
        className={`fixed z-40 inset-y-0 left-0 w-64 bg-blue-800 text-white transform ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } transition-transform duration-300 ease-in-out lg:static lg:translate-x-0`}
      >
        <div className="flex items-center justify-between px-4 py-3 lg:hidden">
          <h1 className="text-xl font-bold">NGO Panel</h1>
          <button onClick={toggleSidebar}>
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="p-4 space-y-2">
          <Link
            to="/ngo/dashboard"
            className="flex items-center space-x-2 px-4 py-2 rounded hover:bg-blue-700"
          >
            <HomeIcon className="w-5 h-5" />
            <span>Dashboard</span>
          </Link>
          <Link
            to="/ngo/black-list"
            className="flex items-center space-x-2 px-4 py-2 rounded hover:bg-blue-700"
          >
            <UsersIcon className="w-5 h-5" />
            <span>Blacklist</span>
          </Link>
          <Link
            to="/ngo/transactions"
            className="flex items-center space-x-2 px-4 py-2 rounded hover:bg-blue-700"
          >
            <BanknotesIcon className="w-5 h-5" />
            <span>Transactions</span>
          </Link>
          <Link
            to="/ngo/reminder"
            className="flex items-center space-x-2 px-4 py-2 rounded hover:bg-blue-700"
          >
            <BanknotesIcon className="w-5 h-5" />
            <span>Reminder</span>
          </Link>
          <Link
            to="/ngo/volunteer"
            className="flex items-center space-x-2 px-4 py-2 rounded hover:bg-blue-700"
          >
            <BanknotesIcon className="w-5 h-5" />
            <span>Volunteer</span>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar for small screens */}
        <header className="lg:hidden bg-white shadow p-4 flex items-center justify-between">
          <button onClick={toggleSidebar}>
            <Bars3Icon className="w-6 h-6 text-gray-800" />
          </button>
          <h1 className="text-xl font-semibold">NGO Dashboard</h1>
        </header>

        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default NGOLayout;
