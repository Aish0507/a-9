import { Navigate, Route, Routes } from "react-router-dom";
import { NGODashboard } from "../components/NGODashboard";
import { BlacklistManager } from "../components/BlacklistManager";
import { ContractPreview } from "../components/ContractPreview";
import { NGOTransactionReview } from "../components/NGOTransactionReview";
import { ReminderManager } from "../components/ReminderManager";
import { VolunteerAssistancePanel } from "../components/VolunteerAssistancePanel";
import NGOLayout from "../layout/NGOLayout";

export const NGORoutes = () => {
  return (
    <Routes>
      <Route element={<NGOLayout />}>
      <Route path="/" element={<Navigate to="dashboard" />} />
      <Route path="dashboard" element={<NGODashboard />} />
      <Route path="black-list" element={<BlacklistManager />} />
      <Route path="contract" element={<ContractPreview />} />
      <Route path="transactions" element={<NGOTransactionReview />} />
      <Route path="reminder" element={<ReminderManager />} />
      <Route path="volunteer" element={<VolunteerAssistancePanel />} />
      </Route>
      
       {/* <Route path="*" element={<Navigate to="/" replace />} /> */}
    </Routes>
  );
};