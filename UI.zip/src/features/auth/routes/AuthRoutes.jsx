import { Route, Routes } from "react-router-dom";
import { LoginForm } from "../components/LoginForm";
import { RegisterForm } from "../components/RegisterForm";
import Landing from "../../../components/Landing";

export const AuthRoutes = () => {
  return (
    <Routes>
      <Route path="login" element={<LoginForm />} />
      <Route path="register" element={<RegisterForm />} />
      <Route path="landing" element={<Landing />} />
    </Routes>
  );
};
