// export const LoginForm = () => <div>Login Form</div>;
import React, { useState } from 'react';
import { LockClosedIcon, EnvelopeIcon } from '@heroicons/react/24/outline';
import { Link, useNavigate } from 'react-router-dom';

// export const LoginForm = () => {
//   return (
//     <div className="min-h-screen flex items-center justify-center bg-gray-100">
//       <div className="max-w-md w-full bg-white p-8 rounded-lg shadow">
//         <h2 className="text-2xl font-bold mb-6 text-center text-black">Login</h2>

//         <form className="space-y-4">
//           <div>
//             <label className="block text-sm font-medium mb-1">Email</label>
//             <div className="relative">
//               <EnvelopeIcon className="w-5 h-5 absolute left-3 top-2.5 text-gray-400" />
//               <input
//                 type="email"
//                 className="w-full pl-10 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
//                 placeholder="Enter your email"
//               />
//             </div>
//           </div>

//           <div>
//             <label className="block text-sm font-medium mb-1">Password</label>
//             <div className="relative">
//               <LockClosedIcon className="w-5 h-5 absolute left-3 top-2.5 text-gray-400" />
//               <input
//                 type="password"
//                 className="w-full pl-10 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
//                 placeholder="Enter your password"
//               />
//             </div>
//           </div>

//           <button
//             type="submit"
//             className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700"
//           >
//             Sign In
//           </button>
//         </form>

//         <p className="text-center text-sm text-gray-600 mt-4">
//           Don’t have an account?{' '}
//           <Link to="/auth/register" className="text-blue-600 hover:underline">
//             Register here
//           </Link>
//         </p>
//       </div>
//     </div>
//   );
// };

// export default Login;

// import React from 'react';
import { FaApple, FaGoogle, FaMicrosoft, FaUser, FaLock } from 'react-icons/fa';

export const LoginForm = () => {
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({ name: "", phone: "" });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleLogin = (e) => {
    e.preventDefault();
    const savedUser = JSON.parse(localStorage.getItem("user"));

    if (
      savedUser &&
      savedUser.name === credentials.name &&
      savedUser.phone === credentials.phone
    ) {
      navigate("/auth/landing");
    } else {
      setError("Invalid credentials. Please try again.");
    }
  };
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-[#0f1120] to-[#08101e] px-4">
      <div className="w-full max-w-md bg-[#0e1225] rounded-3xl shadow-2xl p-6 text-white relative">
        {/* Cute Bot Illustration */}
        <div className="flex justify-center mb-4">
          <img
            src="/logo3.png" // Replace with your bot image path
            // src="/ai-robot.png" // Replace with your bot image path
            alt="Robot"
            className="w-32 h-32 object-contain animate-bounce-"
          />
        </div>

        {/* Sign In Title */}
        <h2 className="text-3xl font-bold text-center mb-1">Sign in</h2>
        <p className="text-sm text-gray-400 text-center mb-1">Access to your account</p>
        <p className="text-sm text-gray-400 text-center mb-6 underline" onClick={()=> navigate("/auth/register")}>OR Register Here</p>
      {error && (
          <div className="text-red-400 text-sm text-center">{error}</div>
        )}
        {/* Input Fields */}
        <div className="space-y-4">
          <div className="relative">
            <FaUser className="absolute left-3 top-3 text-gray-400" />
            <input
            value={credentials.name}
              onChange={handleChange}
              name="name"
              type="text"
              placeholder="Username"
              className="w-full py-3 pl-10 pr-4 rounded-xl bg-[#161b30] text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <FaLock className="absolute left-3 top-3 text-gray-400" />
            <input
             value={credentials.phone}
              onChange={handleChange}
              name="phone"
              type="text"
              placeholder="phone number"
              className="w-full py-3 pl-10 pr-4 rounded-xl bg-[#161b30] text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Sign In Button */}
        <button className="mt-6 w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 transition duration-300 text-white font-semibold"
        onClick={handleLogin}>
          Sign In
        </button>

        {/* Or Sign in With */}
        <div className="text-center text-gray-400 mt-6 mb-4 text-sm">Or Sign In With</div>

        {/* Social Buttons */}
        <div className="space-y-3">
          <button className="flex items-center justify-center w-full gap-3 py-3 bg-black rounded-xl hover:bg-gray-800 transition">
            <FaApple className="text-white" />
            <span>Apple</span>
          </button>
          <button className="flex items-center justify-center w-full gap-3 py-3 bg-black rounded-xl hover:bg-gray-800 transition">
            <FaGoogle className="text-white" />
            <span>Google</span>
          </button>
          <button className="flex items-center justify-center w-full gap-3 py-3 bg-black rounded-xl hover:bg-gray-800 transition">
            <FaMicrosoft className="text-white" />
            <span>Microsoft</span>
          </button>
        </div>
      </div>
    </div>
  );
};

// export default Login;

