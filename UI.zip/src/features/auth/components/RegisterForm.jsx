// export const RegisterForm = () => <div>Register Form</div>;
import React from 'react';
import { LockClosedIcon, EnvelopeIcon, UserIcon } from '@heroicons/react/24/outline';
import { Link } from 'react-router-dom';

// export const RegisterForm = () => {
//   return (
//     <div className="min-h-screen flex items-center justify-center bg-gray-100">
//       <div className="max-w-md w-full bg-white p-8 rounded-lg shadow">
//         <h2 className="text-2xl font-bold mb-6 text-center text-black">Register</h2>

//         <form className="space-y-4">
//           <div>
//             <label className="block text-sm font-medium mb-1">Name</label>
//             <div className="relative">
//               <UserIcon className="w-5 h-5 absolute left-3 top-2.5 text-gray-400" />
//               <input
//                 type="text"
//                 className="w-full pl-10 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
//                 placeholder="Enter your name"
//               />
//             </div>
//           </div>

//           <div>
//             <label className="block text-sm font-medium mb-1">Email</label>
//             <div className="relative">
//               <EnvelopeIcon className="w-5 h-5 absolute left-3 top-2.5 text-gray-400" />
//               <input
//                 type="email"
//                 className="w-full pl-10 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
//                 placeholder="Enter your email"
//               />
//             </div>
//           </div>

//           <div>
//             <label className="block text-sm font-medium mb-1">Password</label>
//             <div className="relative">
//               <LockClosedIcon className="w-5 h-5 absolute left-3 top-2.5 text-gray-400" />
//               <input
//                 type="password"
//                 className="w-full pl-10 border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
//                 placeholder="Create a password"
//               />
//             </div>
//           </div>

//           <button
//             type="submit"
//             className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700"
//           >
//             Register
//           </button>
//         </form>

//         <p className="text-center text-sm text-gray-600 mt-4">
//           Already have an account?{' '}
//           <Link to="/auth/login" className="text-blue-600 hover:underline">
//             Login
//           </Link>
//         </p>
//       </div>
//     </div>
//   );
// };

import { useState } from "react";
import { useNavigate } from "react-router-dom";

export const RegisterForm = () => {
   const navigate = useNavigate();
  const [user, setUser] = useState({ name: "", phone: "" });

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    localStorage.setItem("user", JSON.stringify(user));
    navigate("/auth/landing");
  };


  return (
     <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-[#0f1120] to-[#08101e] px-4">
      <div className="w-full max-w-md bg-[#0e1225] rounded-3xl shadow-2xl p-6 text-white relative">
        {/* Chatbot Image */}
        <div className="flex justify-center">
          <img
            src="/logo3.png"
            alt="Chatbot"
            className="w-32 h-32 animate-bounce- object-contain"
          />
        </div>

        <h2 className="text-center text-2xl font-semibold">Welcome!</h2>
        <p className="text-center text-sm text-gray-300">
          Register to start your smart farming journey 🌾
        </p>
        <p className="text-center text-sm text-gray-300 underline" onClick={()=>navigate('/auth/login')}>
          OR Login
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-gray-300 mb-1">Name</label>
            <input
              type="text"
              name="name"
              value={user.name}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 rounded-xl bg-gray-800 text-white border border-gray-600 focus:ring-2 focus:ring-green-400 outline-none"
              placeholder="Enter your name"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-300 mb-1">Phone</label>
            <input
              type="tel"
              name="phone"
              value={user.phone}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 rounded-xl bg-gray-800 text-white border border-gray-600 focus:ring-2 focus:ring-green-400 outline-none"
              placeholder="Enter your phone"
            />
          </div>
          <button
            type="submit"
            className="mt-6 w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 transition duration-300 text-white font-semibold"
          >
            Register
          </button>
        </form>
      </div>
    </div>
  );
}

