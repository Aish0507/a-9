import { Navigate, Route, BrowserRouter as Router, Routes, useNavigate } from 'react-router-dom';

import { AuthRoutes } from '../features/auth/routes/AuthRoutes';
import { CreditorRoutes } from '../features/creditor/routes/CreditorRoutes';
import { DebtorRoutes } from '../features/debtor/routes/DebtorRoutes';
import { NGORoutes } from '../features/ngo/routes/NGORoutes';
import { useHotkeys } from 'react-hotkeys-hook';

const AppRoutes = () => {
    const navigate = useNavigate();
    useHotkeys('shift+n', () => {
        navigate('/ngo/dashboard');
    })
    useHotkeys('shift+c', () => {
        navigate('/creditor/dashboard');
    })
    useHotkeys('shift+d', () => {
        navigate('/debtor/dashboard');
    })
     useHotkeys('shift+l', () => {
        navigate('/auth/login');
    })
     useHotkeys('shift+r', () => {
        navigate('/auth/register');
    })
     useHotkeys('shift+1', () => {
        navigate('/auth/landing');
    })
     useHotkeys('shift+i', () => {
        navigate('/creditor/intro');
    })
    useHotkeys('shift+p', () => {
        navigate('/creditor/prompt');
    })
    return (
        <Routes>
            <Route path="/" element={<Navigate to="/auth/login" />} />
            <Route path="/ngo/*" element={<NGORoutes />} />
            <Route path="/auth/*" element={<AuthRoutes />} />
            <Route path="/creditor/*" element={<CreditorRoutes />} />
            <Route path="/debtor/*" element={<DebtorRoutes />} />
        </Routes>
    );
};

export default AppRoutes;
