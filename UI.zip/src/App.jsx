import AppRoutes  from './routes/AppRoutes';
const App = () => <AppRoutes />;
export default App;