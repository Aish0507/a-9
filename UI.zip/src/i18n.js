import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import en from './locales/en/translation.json';
import hi from './locales/hi/translation.json';
import mr from './locales/mr/translation.json';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    debug: true, // Optional: enables console logs for debugging
    fallbackLng: 'en-US',
    resources: {
      'en-US': { translation: en },
      'hi-IN': { translation: hi },
      'mr-IN': { translation: mr },
    },
    interpolation: {
      escapeValue: false,
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
    },
    react: {
      useSuspense: false, // If you're not using React Suspense
    },
  });

export default i18n;
