import React, { useEffect, useState } from 'react';
import { FiSend, FiMic, FiFlag } from 'react-icons/fi';
import { BsStars } from 'react-icons/bs';
import { AiOutlinePicture } from 'react-icons/ai';
import Camera from 'react-html5-camera-photo';
import 'react-html5-camera-photo/build/css/index.css';
import { FlagIcon } from '@heroicons/react/24/solid';
import { FaLanguage, FaSignLanguage } from 'react-icons/fa';
import LanguageToggle from './LanguageToggle';
import { useTranslation } from 'react-i18next';
const FooterInputBar = ({ onSend = () => { }, externalPrompt = '' }) => {
    let isChatOpen = false;
    let recognitionActive = false;
    const [showUpload, setShowUpload] = useState(false);
    const [isCameraOpen, setIsCameraOpen] = useState(false);
    const [dataUri, setDataUri] = useState('');
    const [isLoading, setIsLoading] = useState(false)
    const { i18n, t } = useTranslation();

    useEffect(() => {
        if (externalPrompt) {
            setInput(externalPrompt);
            askQuestion()
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [externalPrompt]);
    const handleTakePhoto = (dataUri) => {
        setDataUri(dataUri); // base64 image data
        setIsCameraOpen(false);
    };
    const [input, setInput] = useState('');

    const handleSend = (value) => {
        const message = value || input;
        if (!message.trim()) return;
        setInput('');
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    };
    const toggleUpload = () => setShowUpload(!showUpload);
    const saveToLocalStorage = (question, answer) => {
        const key = 'qaList';
        const existing = JSON.parse(localStorage.getItem(key) || '[]');
        const updated = [...existing, { question, answer }];
        localStorage.setItem(key, JSON.stringify(updated));
    };
    function stripHTML(htmlString) {
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = htmlString;
        return tempDiv.textContent || tempDiv.innerText || "";
    }
    const staticAns = ` <ol className="list-decimal space-y-4 pl-5">
    <li>
      <strong>लोन की पूरी जानकारी:</strong>
      <ul className="list-disc pl-5">
        <li>मूलधन: ₹50,000</li>
        <li>सालाना ब्याज: 5%</li>
        <li>कुल चुकानी राशि: लगभग ₹52,500</li>
        <li>महीने की EMI: करीब ₹5,250</li>
      </ul>
    </li>

    <li>
      <strong>आपकी बैंक खाते की जानकारी के अनुसार:</strong>
      <ul className="list-disc pl-5">
        <li>महीने की औसत आय: ₹8,000</li>
        <li>फसल के समय थोड़ी ज्यादा आमदनी होती है</li>
        <li>दूसरे स्रोतों से कुछ अतिरिक्त आय हो सकती है</li>
      </ul>
    </li>

    <li>
      <strong>फसल लगाने की सलाह (आगामी 10 महीने के लिए):</strong>

      <p className="mt-2"><strong>खरीफ सीजन (जुलाई - अक्टूबर):</strong></p>
      <ul className="list-disc pl-5">
        <li>धान की जगह मक्का लगाएं – यह कम पानी में भी ठीक होता है और जल्दी तैयार होता है।</li>
        <li>अरहर दाल भी साथ में लगाएं, जल्दी कटाई होगी।</li>
        <li>अनुमानित आय: लगभग ₹35,000</li>
      </ul>

      <p className="mt-2"><strong>रबी सीजन (नवंबर - मार्च):</strong></p>
      <ul className="list-disc pl-5">
        <li>गेहूं और सरसों साथ-साथ लगाएं।</li>
        <li>मटर की फसल भी लाभदायक है, बाजार में अच्छा भाव मिल सकता है।</li>
        <li>अनुमानित आय: लगभग ₹40,000</li>
      </ul>
    </li>

    <li>
      <strong>EMI चुकाने का आसान योजना:</strong>
      <p className="mt-2"><strong>महीने 1 से 4 (खरीफ सीजन):</strong></p>
      <ul className="list-disc pl-5">
        <li>मक्का और अरहर से लगभग ₹8,000 कमाई।</li>
        <li>PM-KISAN योजना से ₹500 प्रति महीने मिलेगा।</li>
        <li>कुल ₹8,500 में से आप आसानी से ₹5,250 EMI दे सकते हैं।</li>
      </ul>

      <p className="mt-2"><strong>महीने 5 से 10 (रबी सीजन):</strong></p>
      <ul className="list-disc pl-5">
        <li>गेहूं, सरसों और मटर से ₹8,000 की आमदनी।</li>
        <li>मटर की बिक्री से अतिरिक्त ₹15,000 मिल सकता है।</li>
        <li>EMI के बाद बचत भी होगी।</li>
      </ul>
    </li>

    <li>
      <strong>मौसम, मिट्टी और मंडी से मदद:</strong>
      <ul className="list-disc pl-5">
        <li>आपके इलाके में अब बारिश की अच्छी संभावना है।</li>
        <li>मिट्टी काली है, जो मक्का, अरहर, गेहूं और सरसों के लिए उपयुक्त है।</li>
        <li>मंडी के दाम भी मक्का ₹17/kg, अरहर ₹65/kg, गेहूं ₹22/kg और सरसों ₹55/kg अच्छे हैं।</li>
        <li>आपके ऐप की मदद से आप हर सीजन के हिसाब से सबसे बढ़िया फसल चुन सकते हैं।</li>
      </ul>
    </li>

    <li>
      <strong>सरकारी योजनाएँ और अन्य मदद:</strong>
      <ul className="list-disc pl-5">
        <li>KCC (किसान क्रेडिट कार्ड) से 4% ब्याज पर लोन ले सकते हैं।</li>
        <li>PMFBY फसल बीमा करवाएं, प्रीमियम महज ₹300 – नुकसान होने पर मदद मिलेगी।</li>
        <li>समय पर लोन चुकाने पर KCC पर 3% ब्याज में छूट भी मिलती है।</li>
      </ul>
    </li>

    <li>
      <strong>अगर EMI नहीं भर पाए तो क्या करें?</strong>
      <ul className="list-disc pl-5">
        <li>अपने बैंक मैनेजर से बात करें, किश्तों का समय बढ़वाने या पुनर्गठन की मांग करें।</li>
        <li>सहायता के लिए इन नंबरों पर कॉल करें:</li>
        <ul className="list-disc pl-10">
          <li>Grand Maratha Foundation: 022-6275 7075</li>
          <li>BAIF Nashik Branch: 0253-2416057</li>
          <li>PRADAN Helpdesk: 0120-4800800</li>
          <li>IFFCO Kisan Helpline: 1800-2035972</li>
          <li>Farm Aid Hotline (मानसिक सहायता): 800-3276243</li>
        </ul>
        <li>नजदीकी बैंक के शाखा प्रबंधक से संपर्क करें।</li>
      </ul>
    </li>

    <li>
      <strong>आसान सलाह और सारांश:</strong>
      <ul className="list-disc pl-5">
        <li>हर महीने ₹5,250 EMI देने के लिए खरीफ (मक्का, अरहर) और रबी (गेहूं, सरसों, मटर) सीजन की अच्छी फसल लगाएं।</li>
        <li>मौसम और मंडी भाव के अनुसार फसल का चुनाव करें।</li>
        <li>सरकारी योजना और क्रेडिट कार्ड का पूरा लाभ उठाएं।</li>
        <li>भुगतान में दिक्कत हो तो समय रहते मदद मांगें।</li>
      </ul>
      <p><strong>कहावत:</strong><br />{"सही फसल, सही योजना से कर्ज़ का बोझ होगा कम, जीवन होगा आसान।"}</p>
    </li>
  </ol>`
    const askQuestion = () => {
        handleSend();
        const question = document.getElementById('question').value;
        if (!question.trim()) return;
        if (question === 'मेरा ₹50,000 का लोन है, 25% ब्याज, 10 महीने में चुकाना है। मुझे क्या करना चाहिए?') {
            const plainText = `
लोन की पूरी जानकारी:
मूलधन: ₹50,000
सालाना ब्याज: 5%
कुल चुकानी राशि: लगभग ₹52,500
महीने की EMI: करीब ₹5,250
आपकी बैंक खाते की जानकारी के अनुसार
महीने की औसत आय: ₹8,000
फसल के समय थोड़ी ज्यादा आमदनी होती है
दूसरे स्रोतों से कुछ अतिरिक्त आय हो सकती है
फसल लगाने की सलाह (आगामी 10 महीने के लिए)
खरीफ सीजन (जुलाई - अक्टूबर)
धान की जगह मक्का लगाएं - यह कम पानी में भी ठीक होता है और जल्दी तैयार होता है।
अरहर दाल भी साथ में लगाएं, जल्दी कटाई होगी।
अनुमानित आय: लगभग ₹35,000
रबी सीजन (नवंबर - मार्च)
गेहूं और सरसों साथ-साथ लगाएं।
मटर की फसल भी लाभदायक है, बाजार में अच्छा भाव मिल सकता है।
अनुमानित आय लगभग ₹40,000
EMI चुकाने का आसान योजना
महीने 1 से 4 (खरीफ सीजन)
मक्का और अरहर से लगभग ₹8,000 कमाई।
PM-KISAN योजना से ₹500 प्रति महीने मिलेगा।
कुल ₹8,500 में से आप आसानी से ₹5,250 EMI दे सकते हैं।
महीने 5 से 10 (रबी सीजन)
गेहूं, सरसों और मटर से ₹8,000 की आमदनी।
मटर की बिक्री से अतिरिक्त ₹15,000 मिल सकता है।
EMI के बाद बचत भी होगी।
मौसम, मिट्टी और मंडी से मदद
आपके इलाके में अब बारिश की अच्छी संभावना है।
मिट्टी काली है, जो मक्का, अरहर, गेहूं और सरसों के लिए उपयुक्त है।
मंडी के दाम भी मक्का ₹17/kg, अरहर ₹65/kg, गेहूं ₹22/kg और सरसों ₹55/kg अच्छे हैं।
आपके ऐप की मदद से आप हर सीजन के हिसाब से सबसे बढ़िया फसल चुन सकते हैं।
सरकारी योजनाएँ और अन्य मदद:
KCC (किसान क्रेडिट कार्ड) से 4% ब्याज पर लोन ले सकते हैं।
PMFBY फसल बीमा करवाएं, प्रीमियम महज ₹300  नुकसान होने पर मदद मिलेगी।
समय पर लोन चुकाने पर KCC पर 3% ब्याज में छूट भी मिलती है।
अगर EMI नहीं भर पाए तो क्या करें?
अपने बैंक मैनेजर से बात करें, किश्तों का समय बढ़वाने या पुनर्गठन की मांग करें।
सहायता के लिए इन नंबरों पर कॉल करें:
Grand Maratha Foundation: 022-6275 7075
BAIF Nashik Branch: 0253-2416057
PRADAN Helpdesk: 0120-4800800
IFFCO Kisan Helpline: 1800-2035972
Farm Aid Hotline (मानसिक सहायता): 800-3276243
नजदीकी बैंक के शाखा प्रबंधक से संपर्क करें।
आसान सलाह और सारांश:
हर महीने ₹5,250 EMI देने के लिए खरीफ (मक्का, अरहर) और रबी (गेहूं, सरसों, मटर) सीजन की अच्छी फसल लगाएं।
मौसम और मंडी भाव के अनुसार फसल का चुनाव करें।
सरकारी योजना और क्रेडिट कार्ड का पूरा लाभ उठाएं।
भुगतान में दिक्कत हो तो समय रहते मदद मांगें।
कहावत
सही फसल, सही योजना से कर्ज़ का बोझ होगा कम, जीवन होगा आसान।`;
            getSpeechFromTTS(plainText, getSelectedLanguage(), question);
            const audioBlob = new Blob([plainText], { type: 'audio/mp3' });
            const audioUrl = URL.createObjectURL(audioBlob);

            const audioPlayer = document.getElementById('ttsPlayer');
            audioPlayer.src = audioUrl;
            audioPlayer.play();
            return staticAns
        }
        setIsLoading(true);
        //   addChatCard(question, 'user');
        fetch('https://aarthik-empowerers-chatbot-534301989739.us-central1.run.app/ask', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ question: question })
        })
            .then(res => res.json())
            .then(data => {
                console.log(data)
                setIsLoading(false);
                //   addChatCard(data.answer, 'bot');
                onSend(question, data.answer);
                saveToLocalStorage(question, data.answer)
                // localStorage.setItem(question, data.answer)
                getSpeechFromTTS(data.answer, getSelectedLanguage(), question);
            });
    }
    const getSpeechFromTTS = (text, language, question) => {
        setIsLoading(true);

        fetch('https://aarthik-empowerers-chatbot-534301989739.us-central1.run.app/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: text, language: language })
        })
            .then(response => {
                console.log(response)
                return response.blob()
            })
            .then(blob => {
                console.log(blob)
                onSend(question, staticAns);

                const audioUrl = URL.createObjectURL(blob);
                const audioPlayer = document.getElementById('ttsPlayer');
                audioPlayer.src = audioUrl;
                audioPlayer.style.display = 'block';
                audioPlayer.play();
                setIsLoading(false);

            });
    }
    const startListening = () => {
        const language = 'en-US'//getSelectedLanguage();
        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = language;
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        const indicator = document.getElementById('voiceIndicator');
        indicator.classList.add('active');
        recognitionActive = true;

        recognition.start();

        recognition.onresult = function (event) {
            const transcript = event.results[0][0].transcript;
            document.getElementById('question').value = transcript;
            indicator.classList.remove('active');
            recognitionActive = false;
        };

        recognition.onerror = function (event) {
            alert('Voice Error: ' + event.error);
            indicator.classList.remove('active');
            recognitionActive = false;
        };

        recognition.onend = function () {
            if (recognitionActive) {
                indicator.classList.remove('active');
                recognitionActive = false;
            }
        };
    }
    const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
    const [isListening, setIsListening] = useState(false);

    const handleMicClick = () => {
        if (!SpeechRecognition) {
            // alert(t("chatbot.speechNotSupported"));
            return;
        }

        const recognition = new SpeechRecognition();
        recognition.lang = getSelectedLanguage() //"hi-IN";
        recognition.continuous = false;
        recognition.interimResults = false;

        setIsListening(true);

        recognition.onresult = (event) => {
            const speechToText = event.results[0][0].transcript;
            setInput(speechToText);
            setIsListening(false);
        };

        recognition.onerror = () => {
            // alert(t("chatbot.speechError"));
            setIsListening(false);
        };

        recognition.start();
    };
    const getSelectedLanguage = () => {
        return localStorage.getItem('appLang') || 'en-US' //document.getElementById('languageSelect').value;
    }
    const uploadDocument = () => {
        const fileInput = document.getElementById('docFile');
        const formData = new FormData();
        formData.append('file', fileInput.files[0]);

        fetch('https://aarthik-empowerers-chatbot-534301989739.us-central1.run.app/add_document', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => document.getElementById('uploadResponse').innerText = data.status || data.error);
    }


    function handleTakePhotoAnimationDone(dataUri) {
        // Do stuff with the photo...
        console.log('takePhoto');
    }

    function handleCameraError(error) {
        console.log('handleCameraError', error);
    }

    function handleCameraStart(stream) {
        console.log('handleCameraStart');
    }

    function handleCameraStop() {
        console.log('handleCameraStop');
    }
    const handleSendPhoto = () => {
        // Your send logic here (upload, message, etc.)
        console.log("Sending photo...");
        setIsCameraOpen(false);
        setDataUri('');
    };

    const handleRetake = () => {
        setDataUri('');
    };

    return (
        <>
            {isLoading && 'Please wait...'}
            {isCameraOpen && (
                <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center">

                    <div className="relative w-full max-w-md bg-black rounded-xl overflow-hidden shadow-lg">
                        {!dataUri ? (
                            <>
                                <Camera
                                    onTakePhoto={handleTakePhoto}
                                    isFullscreen={false}
                                    idealFacingMode="environment"
                                />
                                <button
                                    onClick={() => setIsCameraOpen(false)}
                                    className="absolute top-3 right-3 bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-xs"
                                >
                                    ✖ Close
                                </button>
                            </>
                        ) : (
                            <>
                                {/* 📸 Preview */}
                                <img
                                    src={dataUri}
                                    alt="Preview"
                                    className="w-full h-auto object-cover rounded-t-xl"
                                />

                                {/* ✅ Overlay Controls */}
                                <div className="p-4 bg-gray-900 text-white flex justify-between gap-4">
                                    <button
                                        onClick={handleRetake}
                                        className="bg-yellow-500 hover:bg-yellow-600 text-black px-4 py-2 rounded w-full"
                                    >
                                        🔄 Retake
                                    </button>
                                    <button
                                        onClick={handleSendPhoto}
                                        className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded w-full"
                                    >
                                        📤 Send
                                    </button>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            )}
            <div className="fixed bottom-3 left-0 right-0 px-4">
                <audio id="ttsPlayer" controls style={{ display: 'none' }} className="w-full mb-2 rounded-lg bg-gradient-to-br from-green-100 via-white to-green-50 shadow-md"></audio>

                {showUpload && (
                    <div className="w-full bg-gradient-to-br from-[#0f172a] via-[#1e293b] to-[#0f172a] px-4 py-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-4 rounded-b-2xl shadow-inner">
                        <input
                            type="file"
                            id="docFile"
                            className="flex-1 text-sm text-gray-300
           file:mr-3 file:py-2 file:px-4 file:rounded-full
           file:border-0 file:text-sm file:font-semibold
           file:bg-green-600 file:text-white hover:file:bg-green-700
           cursor-pointer bg-transparent"
                        />
                        <button
                            onClick={uploadDocument}
                            className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-lg text-sm whitespace-nowrap shadow-md transition duration-150"
                        >
                            📁 Upload
                        </button>
                        <small id="uploadResponse" className="text-xs text-green-300 pt-1 block sm:col-span-2">
                        </small>
                    </div>
                )}


                {/* ✅ Show captured image preview */}
                {dataUri && (
                    <div className="fixed inset-0 z-50 bg-black bg-opacity-90 flex flex-col items-center justify-center p-4">
                        <h3 className="text-white text-lg font-semibold mb-4">📷 Preview</h3>

                        <img
                            src={dataUri}
                            alt="captured"
                            className="w-72 sm:w-96 rounded-lg shadow-lg border-2 border-white"
                        />

                        <div className="mt-6 w-full max-w-sm flex flex-col sm:flex-row gap-4 px-2">
                            <button
                                onClick={handleRetake}
                                className="bg-yellow-500 hover:bg-yellow-600 text-black font-medium px-4 py-2 rounded w-full shadow-lg"
                            >
                                🔄 Retake
                            </button>
                            <button
                                onClick={handleSendPhoto}
                                className="bg-green-500 hover:bg-green-600 text-white font-medium px-4 py-2 rounded w-full shadow-lg"
                            >
                                📤 Send
                            </button>
                        </div>

                        <button
                            onClick={() => setDataUri("")}
                            className="absolute top-4 right-4 bg-red-600 hover:bg-red-700 text-white text-sm px-3 py-1 rounded-full"
                        >
                            ✖
                        </button>
                    </div>
                )}



                <div className="bg-[#0e1225] rounded-full flex items-center px-3 py-2 shadow-xl gap-2 max-w-2xl mx-auto">
                    <div className="flex items-center gap-2 shrink-0">
                        {/* <BsStars className="text-white text-lg" /> */}
                        <span className="text-white text-lg" onClick={toggleUpload}>
                            📁
                        </span>


                        {/* <AiOutlinePicture className="text-white text-xl" onClick={() => setIsCameraOpen(true)} /> */}
                        <FiMic className="text-white text-lg" onClick={handleMicClick} />
                        <LanguageToggle />
                        {/* <FaLanguage className="text-white text-lg" onClick={startListening} /> */}
                    </div>
                    <input
                        value={t(input)}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={handleKeyDown}
                        type="text"
                        id="question"
                        placeholder="Ask me anything..."
                        className="flex-1 min-w-0 bg-transparent outline-none text-white text-sm placeholder-gray-400 px-2"
                    />

                    <button className="text-white bg-blue-600 p-2 rounded-full hover:bg-blue-700 transition shrink-0"
                        onClick={askQuestion}>
                        <FiSend className="text-white text-sm" />
                    </button>
                </div>
            </div>
        </>
    );
};

export default FooterInputBar;
