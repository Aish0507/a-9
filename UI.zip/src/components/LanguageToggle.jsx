import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { FaLanguage } from "react-icons/fa";

const languageMap = {
  "हिंदी": "hi-IN",
  "English": "en-US",
//   "ગુજરાતી": "gu-IN",
  "मराठी": "mr-IN",
//   "বাংলা": "bn-IN",
};

const LanguageToggle = () => {
  const defaultLang = Object.keys(languageMap).find(
    (key) => languageMap[key] === localStorage.getItem("appLang")
  ) || "हिंदी";
  const { i18n } = useTranslation();

  const [isOpen, setIsOpen] = useState(false);
  const [selected, setSelected] = useState(defaultLang);

  const toggleLang = () => setIsOpen(!isOpen);
  const handleSelect = (lang) => {
    setSelected(lang);
    localStorage.setItem("appLang", languageMap[lang]);
    setIsOpen(false);
    console.log(languageMap[lang])
    i18n.changeLanguage(languageMap[lang]);
  };

  return (
    <div className="relative">
      {/* Icon Only */}
      <FaLanguage
        onClick={toggleLang}
        className="text-white text-xl cursor-pointer"
      /> 
      {isOpen && (
        <ul className="absolute bottom-full mb-2 right-0 w-28 bg-white rounded shadow z-50 text-sm">
          {Object.keys(languageMap).map((lang) => (
            <li
              key={lang}
              onClick={() => handleSelect(lang)}
              className="px-3 py-2 hover:bg-green-100 cursor-pointer text-black"
            >
              {lang}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default LanguageToggle;
