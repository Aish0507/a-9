import React, { useState } from 'react';
import {
    FaArrowLeft,
    FaVolumeUp,
    FaSun,
    FaCloud,
    FaBolt,
} from 'react-icons/fa';
import FooterInputBar from './FooterInputBar';
import { useNavigate } from 'react-router-dom';
import ChatBotScreen from './ChatBotScreen';

const ChatIntroScreen = () => {
    const [initialPrompt, setInitialPrompt] = useState("");

    const navigate = useNavigate();
    const goTo = (link) => {
        navigate(link)
    }
    const handlePromptSelect = (question) => {
        setInitialPrompt(question); // Send question to child
    };
    const promptSections = [
        {
            icon: <FaSun className="text-white text-2xl" />,
            iconBg: 'bg-violet-600',
            dotColor: 'bg-purple-400',
            messages: [
                'Explain quantum computing in simple terms',
                'How do I make an HTTP in Javascript?'
            ]
        },
        {
            icon: <FaCloud className="text-white text-2xl" />,
            iconBg: 'bg-cyan-500',
            dotColor: 'bg-cyan-400',
            messages: [
                'Remembers what user said earlier',
                'Allows user to provide follow-up corrections'
            ]
        },
        {
            icon: <FaBolt className="text-black text-2xl" />,
            iconBg: 'bg-yellow-400',
            dotColor: 'bg-yellow-300',
            messages: [
                'May occasionally generate incorrect'
            ]
        }
    ];
    const formatDate = (date = new Date()) => {
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const year = String(date.getFullYear()).slice(-2); // Get last 2 digits

        return `${day}.${month}.${year}`;
    }
    return (
        <div className="min-h-screen w-full bg-gradient-to-b from-[#0f172a] via-[#1e293b] to-[#0f172a] flex flex-col text-white px-4 py-6">
            {/* Header */}
            <div className="fixed top-0 left-0 w-full z-20 bg-[#0f172a] shadow-md flex items-center justify-between mb-6">
                <button>
                    <FaArrowLeft className="text-white text-xl" onClick={() => goTo('/auth/landing')} />
                </button>
                {/* <h2 className="text-sm text-gray-400">Last Update: {formatDate()}</h2> */}
                {localStorage.getItem("appLang")}
                {/* <button>
          <FaVolumeUp className="text-white text-xl" />
        </button> */}
            </div>

            {/* Title */}
            <div className="text-center mb-6">
                <h1 className="text-2xl font-semibold">Hello, Ask Me Anything...</h1>
            </div>

            {/* Main Section */}
            <div className="flex flex-col sm:flex-row justify-center items-start gap-6">
                {promptSections.map((section, i) => (
                    <div key={i} className="flex flex-col items-center gap-2">
                        <div className={`${section.iconBg} rounded-full p-3`}>
                            {section.icon}
                        </div>
                        <div className="flex flex-col gap-2 w-full max-w-sm">
                            {section.messages.map((msg, j) => (
                                <div
                                    key={j}
                                    className="bg-black/30 rounded-full px-4 py-2 text-sm flex items-center gap-2"
                                    onClick={() => handlePromptSelect(msg)}
                                >
                                    <span className={`h-2 w-2 ${section.dotColor} rounded-full`} />
                                    {msg}
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
            <ChatBotScreen selectedPrompt={initialPrompt} />
            {/* <FooterInputBar /> */}
        </div>
    );
};

export default ChatIntroScreen;
