import { useLocation } from 'react-router-dom';
import { useEffect, useRef, useState } from 'react';
import FooterInputBar from './FooterInputBar';

const ChatBotScreen = ({ selectedPrompt }) => {
  const location = useLocation();
  const { prompt } = location.state || {};
  const [messages, setMessages] = useState([]);
  const [messageHistory, setMessageHistory] = useState([]);
  const [externalMessage, setExternalMessage] = useState('');
useEffect(() => {
    if (selectedPrompt) {
      setExternalMessage(selectedPrompt); // Trigger FooterInputBar
    }
  }, [selectedPrompt]);
  useEffect(() => {
    if (prompt) {
      setMessages([
        { type: 'user', text: prompt },
        { type: 'bot', text: 'Sure! Here’s a response for that...' }, // Replace with GPT API response
      ]);
    }
  }, [prompt]);
//  const handleSendMessage = (msg) => {
//     setMessages((prev) => [
//       ...prev,
//       { type: 'user', text: msg },
//       { type: 'bot', text: `${msg}` },
//     ]);
//     setMessageHistory((prev) => [...prev, { type: 'user', text: msg }]);
//   };
const handleSendMessage = (userMsg, botReply) => {
  setMessages((prev) => [
    ...prev,
    { type: 'user', text: userMsg },
    { type: 'bot', text: botReply },
  ]);

  setMessageHistory((prev) => [
    ...prev,
    { type: 'user', text: userMsg },
  ]);
};
const chatContainerRef = useRef(null);
  useEffect(() => {
  const container = document.getElementById('chat-container');
  container?.scrollTo({ top: 0, behavior: 'smooth' });
  console.log(container)
  if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
}, [messages]);
const formatMarkdown = (markdownText) => {
  return markdownText
    .replace(/\n/g, '<br />')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<li>$1</li>'); // Optional for * bullets
};
const staticAns = ` <ol className="list-decimal space-y-4 pl-5">
    <li>
      <strong>लोन की पूरी जानकारी:</strong>
      <ul className="list-disc pl-5">
        <li>मूलधन: ₹50,000</li>
        <li>सालाना ब्याज: 5%</li>
        <li>कुल चुकानी राशि: लगभग ₹52,500</li>
        <li>महीने की EMI: करीब ₹5,250</li>
      </ul>
    </li>

    <li>
      <strong>आपकी बैंक खाते की जानकारी के अनुसार:</strong>
      <ul className="list-disc pl-5">
        <li>महीने की औसत आय: ₹8,000</li>
        <li>फसल के समय थोड़ी ज्यादा आमदनी होती है</li>
        <li>दूसरे स्रोतों से कुछ अतिरिक्त आय हो सकती है</li>
      </ul>
    </li>

    <li>
      <strong>फसल लगाने की सलाह (आगामी 10 महीने के लिए):</strong>

      <p className="mt-2"><strong>खरीफ सीजन (जुलाई - अक्टूबर):</strong></p>
      <ul className="list-disc pl-5">
        <li>धान की जगह मक्का लगाएं – यह कम पानी में भी ठीक होता है और जल्दी तैयार होता है।</li>
        <li>अरहर दाल भी साथ में लगाएं, जल्दी कटाई होगी।</li>
        <li>अनुमानित आय: लगभग ₹35,000</li>
      </ul>

      <p className="mt-2"><strong>रबी सीजन (नवंबर - मार्च):</strong></p>
      <ul className="list-disc pl-5">
        <li>गेहूं और सरसों साथ-साथ लगाएं।</li>
        <li>मटर की फसल भी लाभदायक है, बाजार में अच्छा भाव मिल सकता है।</li>
        <li>अनुमानित आय: लगभग ₹40,000</li>
      </ul>
    </li>

    <li>
      <strong>EMI चुकाने का आसान योजना:</strong>
      <p className="mt-2"><strong>महीने 1 से 4 (खरीफ सीजन):</strong></p>
      <ul className="list-disc pl-5">
        <li>मक्का और अरहर से लगभग ₹8,000 कमाई।</li>
        <li>PM-KISAN योजना से ₹500 प्रति महीने मिलेगा।</li>
        <li>कुल ₹8,500 में से आप आसानी से ₹5,250 EMI दे सकते हैं।</li>
      </ul>

      <p className="mt-2"><strong>महीने 5 से 10 (रबी सीजन):</strong></p>
      <ul className="list-disc pl-5">
        <li>गेहूं, सरसों और मटर से ₹8,000 की आमदनी।</li>
        <li>मटर की बिक्री से अतिरिक्त ₹15,000 मिल सकता है।</li>
        <li>EMI के बाद बचत भी होगी।</li>
      </ul>
    </li>

    <li>
      <strong>मौसम, मिट्टी और मंडी से मदद:</strong>
      <ul className="list-disc pl-5">
        <li>आपके इलाके में अब बारिश की अच्छी संभावना है।</li>
        <li>मिट्टी काली है, जो मक्का, अरहर, गेहूं और सरसों के लिए उपयुक्त है।</li>
        <li>मंडी के दाम भी मक्का ₹17/kg, अरहर ₹65/kg, गेहूं ₹22/kg और सरसों ₹55/kg अच्छे हैं।</li>
        <li>आपके ऐप की मदद से आप हर सीजन के हिसाब से सबसे बढ़िया फसल चुन सकते हैं।</li>
      </ul>
    </li>

    <li>
      <strong>सरकारी योजनाएँ और अन्य मदद:</strong>
      <ul className="list-disc pl-5">
        <li>KCC (किसान क्रेडिट कार्ड) से 4% ब्याज पर लोन ले सकते हैं।</li>
        <li>PMFBY फसल बीमा करवाएं, प्रीमियम महज ₹300 – नुकसान होने पर मदद मिलेगी।</li>
        <li>समय पर लोन चुकाने पर KCC पर 3% ब्याज में छूट भी मिलती है।</li>
      </ul>
    </li>

    <li>
      <strong>अगर EMI नहीं भर पाए तो क्या करें?</strong>
      <ul className="list-disc pl-5">
        <li>अपने बैंक मैनेजर से बात करें, किश्तों का समय बढ़वाने या पुनर्गठन की मांग करें।</li>
        <li>सहायता के लिए इन नंबरों पर कॉल करें:</li>
        <ul className="list-disc pl-10">
          <li>Grand Maratha Foundation: 022-6275 7075</li>
          <li>BAIF Nashik Branch: 0253-2416057</li>
          <li>PRADAN Helpdesk: 0120-4800800</li>
          <li>IFFCO Kisan Helpline: 1800-2035972</li>
          <li>Farm Aid Hotline (मानसिक सहायता): 800-3276243</li>
        </ul>
        <li>नजदीकी बैंक के शाखा प्रबंधक से संपर्क करें।</li>
      </ul>
    </li>

    <li>
      <strong>आसान सलाह और सारांश:</strong>
      <ul className="list-disc pl-5">
        <li>हर महीने ₹5,250 EMI देने के लिए खरीफ (मक्का, अरहर) और रबी (गेहूं, सरसों, मटर) सीजन की अच्छी फसल लगाएं।</li>
        <li>मौसम और मंडी भाव के अनुसार फसल का चुनाव करें।</li>
        <li>सरकारी योजना और क्रेडिट कार्ड का पूरा लाभ उठाएं।</li>
        <li>भुगतान में दिक्कत हो तो समय रहते मदद मांगें।</li>
      </ul>
      <p><strong>कहावत:</strong><br />{"सही फसल, सही योजना से कर्ज़ का बोझ होगा कम, जीवन होगा आसान।"}</p>
    </li>
  </ol>`
  return (
    <div className="min-h-screen bg-[#0f172a] text-white p-4">
      <h2 className="text-xl font-bold mb-4">Result</h2>
     <div className="space-y-2" id="chat-container" ref={chatContainerRef}>
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`p-3 rounded-xl max-w-xs animate-fade-in-up ${
              msg.type === 'user'
                ? 'bg-blue-600 ml-auto text-right'
                : 'bg-gray-700 mr-auto'
            }`}
            dangerouslySetInnerHTML={{ __html: formatMarkdown(msg.text) }}
          />
           
        ))}
        {/* <div
            className={`p-3 rounded-xl max-w-xs animate-fade-in-up bg-gray-700 mr-auto`}
            dangerouslySetInnerHTML={{ __html: formatMarkdown(staticAns) }}
          /> */}
        {/* {staticAns} */}
      </div>
            <FooterInputBar onSend={handleSendMessage}
            externalPrompt={externalMessage}/>
      
    </div>
  );
};

export default ChatBotScreen;
