import { useTranslation } from 'react-i18next';

const LanguageSwitcher = () => {
  const { i18n } = useTranslation();

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
  };

  return (
    // <div className="flex gap-2 p-2">
    //   <button onClick={() => changeLanguage('en')} className="bg-blue-200 px-3 py-1 rounded">English</button>
    //   <button onClick={() => changeLanguage('hi')} className="bg-green-200 px-3 py-1 rounded">हिन्दी</button>
    //   <button onClick={() => changeLanguage('mr')} className="bg-yellow-200 px-3 py-1 rounded">मराठी</button>
    // </div>
    // <div className="flex flex-wrap justify-center gap-2 p-2  w-full sm:w-fit mx-auto">
    //   <button
    //     onClick={() => changeLanguage('en')}
    //     className="px-4 py-1.5 rounded-full bg-blue-100 hover:bg-blue-200 text-sm font-medium text-blue-900 transition shadow-sm"
    //   >
    //     🇬🇧 English
    //   </button>
    //   <button
    //     onClick={() => changeLanguage('hi')}
    //     className="px-4 py-1.5 rounded-full bg-green-100 hover:bg-green-200 text-sm font-medium text-green-900 transition shadow-sm"
    //   >
    //     🇮🇳 हिन्दी
    //   </button>
    //   <button
    //     onClick={() => changeLanguage('mr')}
    //     className="px-4 py-1.5 rounded-full bg-yellow-100 hover:bg-yellow-200 text-sm font-medium text-yellow-900 transition shadow-sm"
    //   >
    //     🌾 मराठी
    //   </button>
    // </div>
    //  <div className="absolute top-2 right-2 z-10 flex gap-2 flex-wrap">
    //   {[
    //     { code: 'en', label: '🇬🇧 English', color: 'blue' },
    //     { code: 'hi', label: '🇮🇳 हिन्दी', color: 'green' },
    //     { code: 'mr', label: '🌾 मराठी', color: 'yellow' },
    //   ].map(({ code, label, color }) => (
    //     <button
    //       key={code}
    //       onClick={() => changeLanguage(code)}
    //       className={`px-3 py-1.5 text-xs sm:text-sm rounded-full bg-${color}-100 hover:bg-${color}-200 text-${color}-900 font-medium shadow-sm transition`}
    //     >
    //       {label}
    //     </button>
    //   ))}
    // </div>
     <div className="absolute top-4 right-4 z-20 flex gap-2">
        {[
        { code: 'en', label: '🇬🇧', color: 'blue' },
        { code: 'hi', label: '🇮🇳', color: 'green' },
        { code: 'mr', label: '🌾', color: 'yellow' },
        ].map(({ code, label, color }) => (
        <button key={code} onClick={()=> changeLanguage(code)}
            className={`w-9 h-9 text-lg rounded-full bg-${color}-100 text-${color}-800 shadow hover:scale-105
            hover:bg-${color}-200 transition-all`}>
            {label}
        </button>
        ))}
    </div>


  );
};

export default LanguageSwitcher;
