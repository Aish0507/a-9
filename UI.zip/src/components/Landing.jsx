import React from 'react';
import { AiOutlinePicture } from 'react-icons/ai';
import { BsStars } from 'react-icons/bs';
import { FiUser, FiMic, FiSend } from 'react-icons/fi';
import { MdOutlineImage, MdCode, MdTextFields } from 'react-icons/md';
import FooterInputBar from './FooterInputBar';
import { useNavigate } from 'react-router-dom';

const Landing = () => {
    const navigate = useNavigate();
    const goTo = (link) => {
        navigate(link)
    }
    const getFromLocalStorage = () => {
  const key = 'qaList';
  return JSON.parse(localStorage.getItem(key) || '[]');
};

const qaList = getFromLocalStorage();
console.log(qaList);
    return (
        <div className="min-h-screen bg-gradient-to-b from-[#0f1120] to-[#08101e] px-4 py-6 text-white">
            {/* Header Avatar and Title */}
            <div className="flex flex-col items-center space-y-2 mb-6">
                <img
                    src="/logo3.png" // Replace with your avatar image path
                    alt="User Avatar"
                    className="w-32 h-32 rounded-full object-cover"
                />
                <h1 className="text-2xl font-semibold text-center">
                    Welcome to <br />
                    <span className="text-white font-bold text-3xl">AI Chat</span>
                </h1>
            </div>

            {/* Search Bar */}
            {/* <div className="flex items-center bg-[#0e1225] rounded-full px-4 py-3 gap-3 mb-6">
                <FiUser className="text-gray-400" />
                <input
                    type="text"
                    placeholder="Ask me anything..."
                    className="bg-transparent text-white flex-1 outline-none"
                />
                <FiMic className="text-gray-400" />
            </div> */}

            {/* Chat Type Options */}
            <div className="flex justify-around mb-6">
                <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#1b1f3b] hover:bg-[#2b2f4b] transition"
                    onClick={() => goTo('/creditor/prompt')}>
                    <MdTextFields className="text-blue-400 text-lg" />
                    <span className="text-sm">New Chat</span>
                </button>
                {/* <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#1b1f3b] hover:bg-[#2b2f4b] transition"
                    onClick={() => goTo('/creditor/intro')}>
                    <MdOutlineImage className="text-yellow-300 text-lg" />
                    <span className="text-sm">Questions</span>
                </button> */}
                {/* <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#1b1f3b] hover:bg-[#2b2f4b] transition">
                    <MdCode className="text-green-400 text-lg" />
                    <span className="text-sm">Code</span>
                </button> */}
            </div>

            {/* Recent Section */}
            <h2 className="text-sm text-gray-400 font-medium mb-2">RECENT</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Card 1 */}
                {/* <div className="bg-[#0e1225] p-4 rounded-xl shadow-md space-y-2">
                    <h3 className="text-base font-semibold">
                        This is my favorite gaming device...
                    </h3>
                    <p className="text-xs text-blue-400 bg-blue-900 rounded-md px-2 py-1 inline-block w-fit">
                        Which model are you most excited to see?
                    </p>
                    <p className="text-xs text-gray-300">
                        There’s a tough question. I’ve tried all of them, and I found the
                        Xbox one...
                    </p>
                </div> */}
                {qaList.map((item, index) => (
        <div
          key={index}
          className="bg-[#0e1225] p-4 rounded-xl shadow-md space-y-2"
        >
          {/* <h3 className="text-base font-semibold">
            Your Question...
          </h3> */}
          <p className="text-xs text-blue-400 bg-blue-900 rounded-md px-2 py-1 inline-block w-fit">
            {item.question}
          </p>
          <p className="text-xs text-gray-300 line-clamp-3">
            {item.answer}
          </p>
        </div>
      ))}
                {/* Card 2 */}
                {/* <div className="bg-[#0e1225] p-4 rounded-xl shadow-md space-y-2">
                    <h3 className="text-base font-semibold">
                        This is my favorite gaming device...
                    </h3>
                    <p className="text-xs text-blue-400 bg-blue-900 rounded-md px-2 py-1 inline-block w-fit">
                        Which model are you most excited to see?
                    </p>
                    <p className="text-xs text-gray-300">
                        There’s a tough question. I’ve tried all of them, and I found the
                        Xbox one...
                    </p>
                </div> */}
                {/* Card 3 */}
                {/* <div className="bg-[#0e1225] p-4 rounded-xl shadow-md space-y-2">
                    <h3 className="text-base font-semibold">
                        This is my favorite gaming device...
                    </h3>
                    <p className="text-xs text-blue-400 bg-blue-900 rounded-md px-2 py-1 inline-block w-fit">
                        Which model are you most excited to see?
                    </p>
                    <p className="text-xs text-gray-300">
                        There’s a tough question. I’ve tried all of them, and I found the
                        Xbox one...
                    </p>
                </div> */}
                {/* Card 2 - Image Grid */}
                {/* <div className="bg-[#0e1225] p-2 rounded-xl shadow-md grid grid-cols-2 gap-2">
                    <img src="https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg" className="rounded-md object-cover" alt="" />
                    <img src="https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg" className="rounded-md object-cover" alt="" />
                    <img src="https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg" className="rounded-md object-cover" alt="" />
                    <img src="https://images.stockcake.com/public/f/6/d/f6d406c8-d027-4086-b304-8f845f5f6b32_large/golden-wheat-field-stockcake.jpg" className="rounded-md object-cover" alt="" />
                </div> */}

                {/* Card 3 */}
                {/* <div className="bg-[#0e1225] p-4 rounded-xl shadow-md space-y-2">
                    <h3 className="text-base font-semibold">
                        Check Out What Uber Air's Skyport...
                    </h3>
                    <p className="text-xs text-gray-300">
                        Uber is preparing to launch its urban air mobility initiative...
                    </p>
                </div> */}

                {/* Card 4 - Code Sample */}
                {/* <div className="bg-[#0e1225] p-4 rounded-xl shadow-md space-y-2">
                    <h3 className="text-base font-semibold"># UI Color in hex format</h3>
                    <pre className="bg-[#1b1f3b] text-xs p-2 rounded-md text-green-400 overflow-auto">
                        <code>
                            @app.route('/ping', <br />
                            &nbsp;&nbsp;methods=['GET'])
                        </code>
                    </pre>
                </div> */}
            </div>
            {/* <FooterInputBar /> */}

        </div>
    );
};

export default Landing;
