import React, { useEffect, useState } from "react";
import { FaArrowLeft, FaVolumeUp, FaPen, FaChevronRight } from "react-icons/fa";
import FooterInputBar from "./FooterInputBar";
import ChatBotScreen from "./ChatBotScreen";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";

const prompts = [
    "I have a loan of ₹50,000 with 25% interest, which I need to repay in 10 months. What should I do?",
    "Loan Management and Government Schemes",
  "How can I properly manage my loan?",
  "Has the government introduced any loan waiver or assistance schemes for farmers?",
  "If the crop fails, how can the loan be waived?",
  "How can I benefit from the Prime Minister Kisan Samman Nidhi scheme?",
  "What are the benefits of having a Kisan Credit Card?",
  "Side Businesses and Additional Income",
  "Along with farming, what small businesses can I do to earn extra income?",
  "Is it good to rear cows or goats?",
  "Can I do fish farming or poultry farming in Chhattisgarh?",
  "How profitable is making organic manure or compost?",
  "Is there government support for beekeeping or poultry?",
  "Which crop is best suited according to my land?",
  "Which crops are suitable for natural farming?",
  "Investment-Related Questions",
  "Where should I invest my money so I get good returns and no losses?",
  "Is investing in farming equipment or water-saving technologies beneficial?",
  "Is it advisable to get crop insurance?",
  "How should I save for my children’s education and future?",
  "Is investing in Panchayat, banks, or post office schemes a good idea?",
];

const ChatPromptScreen = () => {
    const [initialPrompt, setInitialPrompt] = useState("");
    const { t } = useTranslation();

    const navigate = useNavigate();
    const goTo = (link) => {
        navigate(link);
    };
    const handlePromptSelect = (question) => {
        setInitialPrompt(question); // Send question to child
    };
    const formatDate = (date = new Date()) => {
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const year = String(date.getFullYear()).slice(-2); // Get last 2 digits

        return `${day}.${month}.${year}`;
    }
    const handleStorageChange = (e) => {
        console.log(e)
        if (e.key === 'appLang' && e.newValue) {
            //   setLanguage(e.newValue);
            localStorage.setItem("appLang", e.newValue);

        }
    };

    window.addEventListener('storage', handleStorageChange);


    return (
        <div className="min-h-screen w-full bg-gradient-to-b from-[#0f172a] via-[#0f172a] to-[#1e293b] text-white px-4 py-6 flex flex-col">
            {/* Top bar */}
            <div className="fixed top-0 left-0 w-full z-20 bg-[#0f172a] shadow-md flex justify-between items-center mb-6">
                <FaArrowLeft
                    className="text-xl"
                    onClick={() => goTo("/auth/landing")}
                />
                {/* <FaVolumeUp className="text-xl" /> */}
                {localStorage.getItem("appLang")}
            </div>

            {/* Heading */}
            <div className="text-center mb-2">
                <h1 className="text-2xl font-semibold">
                    Hello, please enter
                    <br />
                    Question?
                </h1>
                <p className="text-gray-400 text-sm mt-2">Last Update: {formatDate()}</p>
            </div>

            {/* Prompt List */}
            <div className="mt-6 flex flex-col gap-3">
                {prompts.map((text, idx) => (
                    <button
                        onClick={() => handlePromptSelect(t(`questions.${text}`))}
                        key={idx}
                        className="flex text-left justify-between bg-white/5 hover:bg-white/10 rounded-xl px-4 py-3"
                    >
                        <div className="flex items-start gap-3">
                            {/* <FaPen className="text-gray-300 text-sm" /> */}
                            <span className="text-sm text-gray-100">{t(`questions.${text}`)}
                                {/* {i18n.language} */}
                            </span>
                        </div>
                        <FaChevronRight className="text-gray-400 text-sm" />
                    </button>
                ))}
            </div>
            {/* chat */}
            <ChatBotScreen selectedPrompt={initialPrompt} />
            <div>

 
</div>

            {/* <FooterInputBar /> */}
        </div>
    );
};

export default ChatPromptScreen;
