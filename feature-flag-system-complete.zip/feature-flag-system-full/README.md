# 🚩 Feature Flag System (Full Version)

## Overview
Enterprise-grade feature flag system for React + TypeScript using values.yaml.

## Features
- Component, Element, Event, Style level flags
- Role-based flags
- Environment-based (values.yaml)
- Hook, HOC, Guard, Wrapper support

## Setup
Wrap your app:

```tsx
<FeatureFlagProvider>
  <App />
</FeatureFlagProvider>
```

## Usage

### Hook
```tsx
const enabled = useFeature("components.userTable")
```

### Component Wrapper
```tsx
<Feature flag="elements.deleteButton">
  <DeleteButton />
</Feature>
```

### Event Guard
```ts
const handler = withFeatureGuard("events.downloadClick", () => {})
```

## Naming Convention
components.*
elements.*
events.*
styles.*

## Notes
- Avoid deep nesting (>4 levels)
- Always use hook/service
