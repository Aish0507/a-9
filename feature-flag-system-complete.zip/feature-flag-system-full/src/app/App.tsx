import React from "react";
import { useFeature } from "../features/feature.hook";

const App = () => {
  const enabled = useFeature("components.userTable");

  return <div>{enabled ? "User Table Enabled" : "Disabled"}</div>;
};

export default App;
