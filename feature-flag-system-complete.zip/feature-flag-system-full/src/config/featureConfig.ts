declare global {
  interface Window {
    __APP_CONFIG__?: any;
  }
}

export const featureConfig = window.__APP_CONFIG__ || {
  featureFlags: {},
};
