import { useFeature } from "./feature.hook";

export const withFeature = (flag: string, Component: any) => {
  return (props: any) => {
    const enabled = useFeature(flag);
    if (!enabled) return null;
    return <Component {...props} />;
  };
};
