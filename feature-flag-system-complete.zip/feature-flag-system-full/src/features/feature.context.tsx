import React, { createContext, useContext } from "react";
import { FeatureFlagService } from "./feature.service";
import { featureConfig } from "../config/featureConfig";

const service = new FeatureFlagService(featureConfig.featureFlags);

const FeatureFlagContext = createContext(service);

export const FeatureFlagProvider = ({ children }: any) => (
  <FeatureFlagContext.Provider value={service}>
    {children}
  </FeatureFlagContext.Provider>
);

export const useFeatureService = () => useContext(FeatureFlagContext);
