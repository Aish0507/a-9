import { useFeatureService } from "./feature.context";

export const useFeature = (flag: string, context?: any) => {
  const service = useFeatureService();
  return service.isEnabled(flag, context);
};
