export class FeatureFlagService {
  private config: any;

  constructor(config: any) {
    this.config = config;
  }

  isEnabled(flag: string, context?: any): boolean {
    const role = context?.role;

    if (role && this.config.roles?.[role]?.[flag] !== undefined) {
      return this.config.roles[role][flag];
    }

    const value = flag.split('.').reduce((acc, key) => acc?.[key], this.config);
    return Boolean(value);
  }
}
