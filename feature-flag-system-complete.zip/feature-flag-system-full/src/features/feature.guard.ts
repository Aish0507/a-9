import { FeatureFlagService } from "./feature.service";
import { featureConfig } from "../config/featureConfig";

const service = new FeatureFlagService(featureConfig.featureFlags);

export const withFeatureGuard = (flag: string, fn: Function) => {
  return (...args: any[]) => {
    if (!service.isEnabled(flag)) return;
    return fn(...args);
  };
};
