import { useFeature } from "./feature.hook";

export const Feature = ({ flag, children, fallback = null }: any) => {
  const enabled = useFeature(flag);
  return enabled ? children : fallback;
};
