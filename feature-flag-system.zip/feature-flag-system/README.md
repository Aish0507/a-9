# 🚩 Feature Flag System

## Overview
Scalable feature flag system for React + TypeScript with YAML-based environments.

## Usage
- Wrap app with FeatureFlagProvider
- Use `useFeature("flag")` to control UI/logic

## Example
```tsx
const enabled = useFeature("components.userTable")
return enabled ? <UserTable /> : null
```
