export class FeatureFlagService {
  constructor(config) {
    this.config = config;
  }

  isEnabled(flag) {
    return flag.split('.').reduce((acc, key) => acc?.[key], this.config);
  }
}
