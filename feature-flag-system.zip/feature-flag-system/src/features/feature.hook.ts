import { useContext } from "react";
import { FeatureContext } from "./feature.context";

export const useFeature = (flag) => {
  const service = useContext(FeatureContext);
  return service.isEnabled(flag);
};
