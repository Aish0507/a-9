import React, { createContext } from "react";
import { FeatureFlagService } from "./feature.service";

const config = window.__APP_CONFIG__?.featureFlags || {};

export const FeatureContext = createContext(
  new FeatureFlagService(config)
);

export const FeatureFlagProvider = ({ children }) => {
  return (
    <FeatureContext.Provider value={new FeatureFlagService(config)}>
      {children}
    </FeatureContext.Provider>
  );
};
